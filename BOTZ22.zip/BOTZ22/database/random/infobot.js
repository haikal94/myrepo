const infobot = (botname, ownername, ownerNumber, prefix) => {
	return `=> INFOBOT <=
❲❋❳ *NAMA* : ${botname}
❲❋❳ *OWNER* : ${ownername}
❲❋❳ *NO.OWNER* : ${prefix}owner
❲❋❳ *PREFIX* : ${prefix}`
}

exports.infobot = infobot
