const infoow = (ownername, instagram, youtube, tiktok, twitter, facebook, asal, umur, agama, gender) => {
	return `=> INFOOWNER <=
❲❋❳ *NAMA* : ${ownername}
❲❋❳ *IG* : ${instagram}
❲❋❳ *YT* : ${youtube}
❲❋❳ *TIKTOK* : ${tiktok}
❲❋❳ *TWITTER* : ${twitter}
❲❋❳ *FB* : ${facebook}
❲❋❳ *ASAL* : ${asal}
❲❋❳ *UMUR* : ${umur}
❲❋❳ *AGAMA* : ${agama}
❲❋❳ *GENDER* : ${gender}`
}

exports.infoow = infoow
