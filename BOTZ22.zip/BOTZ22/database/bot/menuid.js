const menuid = (prefix, botname, ownername, codename, arts, tz) => {
	return `☞ MENU ${botname} ☜
▬▭▬▭▬▭▬▭▬▭▬▭
Halo kak ${codename}.👋
berikut adalah menu *${botname}*
▬▭▬▭▬▭▬▭▬▭▬▭
${arts}
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *LIST-MENU* [ 20 ]
${tz} *${prefix}allmenu* 
${tz} *${prefix}animemenu* 
${tz} *${prefix}audiomenu* 
${tz} *${prefix}bahasamenu* 
${tz} *${prefix}cekmenu* 
${tz} *${prefix}downloadmenu* 
${tz} *${prefix}gamemenu* 
${tz} *${prefix}groupmenu* 
${tz} *${prefix}infomenu* 
${tz} *${prefix}islamimenu* 
${tz} *${prefix}newsmenu* 
${tz} *${prefix}nsfwmenu* 
${tz} *${prefix}ownermenu* 
${tz} *${prefix}randommenu* 
${tz} *${prefix}ratemenu* 
${tz} *${prefix}searchmenu* 
${tz} *${prefix}stickmenu* 
${tz} *${prefix}storagemenu* 
${tz} *${prefix}tagmenu* 
${tz} *${prefix}wallpapermenu*
${tz} *${prefix}hackmenu*  
${tz} *${prefix}setgrub* 
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *TERAPKAN* [ 5M ]
${tz} Memakai masker
${tz} Mencuci tangan
${tz} Menjaga jarak
${tz} Menjauhi kerumunan
${tz} Membatasi mobilitas
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *PERATURAN* [ 5 ]
${tz} Bot ini tidak menyimpan media/foto yang anda kirimkan
${tz} Gunakan bot ini sebaik mungkin
${tz} Jangan spam fitur/command bot
${tz} Bot ini hanya untuk hiburan semata, dan *tidak untuk dimakan*
${tz} Bot ini sekedar bot, tidak dapet berbicara/melakukan hall yang berlebihan seperti manusia
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *HUKUMAN* [ 2 ]
${tz} Owner berhak memberikan teguran hingga sanksi terhadap user yang melanggar peraturan di atas
${tz} Melanggar peraturan di atas dapat mendapatkan sanksi seperti banned/block user
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *THX•TO* [ 6 ]
${tz} *${ownername}*
${tz} *NAYLA [ OTHER ]*
${tz} *LORD RIYAN*
${tz} *LOLKILLERS*
${tz} *ADIWAJSHING*
${tz} *WHATSAPP*
▬▭▬▭▬▭▬▭▬▭▬▭`
}

exports.menuid = menuid
// NOTE THX TO JGN DI HAPUS YAA BANH, HARGAI SAYA(RIMURUBOTZ)
