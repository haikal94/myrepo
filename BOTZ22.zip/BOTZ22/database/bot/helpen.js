const helpen = (prefix, botname, ownername, codename, arts, tz) => {
	return `☞ MENU ${botname} ☜
▬▭▬▭▬▭▬▭▬▭▬▭
Hello brother ${codename}.👋
here is the menu *${botname}*
▬▭▬▭▬▭▬▭▬▭▬▭
${arts}
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *BAHASA* [ 2 ]
${tz} *${prefix}setbahasa* id
${tz} *${prefix}setlanguage* en
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *INFO* [ 7 ]
${tz} *${prefix}iklan*
${tz} *${prefix}sewa*
${tz} *${prefix}scbot*
${tz} *${prefix}mygrub*
${tz} *${prefix}sticker*
${tz} *${prefix}owner*
${tz} *${prefix}chat* <text>
${tz} *${prefix}infoowner*
${tz} *${prefix}infobot*
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *OWNERMENU* [ 12 ]
${tz} *${prefix}setmode* <public/self>
${tz} *${prefix}return* <code>
${tz} *${prefix}setppbot* <reply_img>
${tz} *${prefix}join* <link>
${tz} *${prefix}setprefix* <code>
${tz} *${prefix}bcgc* <text>
${tz} *${prefix}bc* <text>
${tz} *${prefix}dellprem* <@tag>
${tz} *${prefix}addprem* <@tag>
${tz} *${prefix}ban* <@tag>
${tz} *${prefix}unban* <@tag>
${tz} *${prefix}settz*
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *GROUPMENU* [ 24 ]
${tz} *${prefix}tagall* 
${tz} *${prefix}tagall2*
${tz} *${prefix}tagall3* 
${tz} *${prefix}tagall4* 
${tz} *${prefix}tagall5* 
${tz} *${prefix}hidetag* <text>
${tz} *${prefix}leave* 
${tz} *${prefix}delete* <reply>
${tz} *${prefix}sms* <text>
${tz} *${prefix}kickrandom*
${tz} *${prefix}tagtime* <text>|<time>
${tz} *${prefix}linkgrub* 
${tz} *${prefix}listadmin* 
${tz} *${prefix}setdesc* <text>
${tz} *${prefix}setname* <text>
${tz} *${prefix}group* <buka/tutup>
${tz} *${prefix}listonline* 
${tz} *${prefix}add* <62xxx>
${tz} *${prefix}kick* <@tag>
${tz} *${prefix}antivirtex* <on/off>
${tz} *${prefix}antilink* <on/off>
${tz} *${prefix}antitag* <on/off>
${tz} *${prefix}antitoxic* <on/off>
${tz} *${prefix}welcome* <on/off>
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *TAG-RANDOM* [ 22 ]
${tz} *${prefix}sadboy* 
${tz} *${prefix}pakboy* 
${tz} *${prefix}baik* 
${tz} *${prefix}jago* 
${tz} *${prefix}jelek* 
${tz} *${prefix}cantik* 
${tz} *${prefix}pinter* 
${tz} *${prefix}beban* 
${tz} *${prefix}kontol* 
${tz} *${prefix}hebat* 
${tz} *${prefix}wibu* 
${tz} *${prefix}haram* 
${tz} *${prefix}babi* 
${tz} *${prefix}bego* 
${tz} *${prefix}ganteng* 
${tz} *${prefix}anjing* 
${tz} *${prefix}monyet* 
${tz} *${prefix}sadgirl* 
${tz} *${prefix}pakgirl* 
${tz} *${prefix}jahat* 
${tz} *${prefix}nolep* 
${tz} *${prefix}goblok* 
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *RANDOMCEK* [ 22 ]
${tz} *${prefix}bapercek*
${tz} *${prefix}sangecek*
${tz} *${prefix}pakgirlcek*
${tz} *${prefix}pakboycek*
${tz} *${prefix}kontolcek*
${tz} *${prefix}haramcek*
${tz} *${prefix}anjingcek*
${tz} *${prefix}jahatcek*
${tz} *${prefix}baikcek*
${tz} *${prefix}bebancek*
${tz} *${prefix}babicek*
${tz} *${prefix}nolepcek*
${tz} *${prefix}jagocek*
${tz} *${prefix}pintarcek*
${tz} *${prefix}begocek*
${tz} *${prefix}goblokcek*
${tz} *${prefix}jelekcek*
${tz} *${prefix}cantikcek*
${tz} *${prefix}gantengcek*
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *TAGRATE* [ 22 ]
${tz} *${prefix}bapertag* <@tag>
${tz} *${prefix}sangetag* <@tag>
${tz} *${prefix}pakgirltag* <@tag>
${tz} *${prefix}pakboytag* <@tag>
${tz} *${prefix}kontoltag* <@tag>
${tz} *${prefix}haramtag* <@tag>
${tz} *${prefix}anjingtag* <@tag>
${tz} *${prefix}jahattag* <@tag>
${tz} *${prefix}baiktag* <@tag>
${tz} *${prefix}bebantag* <@tag>
${tz} *${prefix}babitag* <@tag>
${tz} *${prefix}noleptag* <@tag>
${tz} *${prefix}jagotag* <@tag>
${tz} *${prefix}pintartag* <@tag>
${tz} *${prefix}begotag* <@tag>
${tz} *${prefix}gobloktag* <@tag>
${tz} *${prefix}jelektag* <@tag>
${tz} *${prefix}cantiktag* <@tag>
${tz} *${prefix}gantengtag* <@tag>
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *WALLPAPER* [ 5 ]
${tz} *${prefix}wallml*
${tz} *${prefix}wallpubg*
${tz} *${prefix}wallneon*
${tz} *${prefix}wallcode*
${tz} *${prefix}wallrandom*
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *DOWNLOAD* [ 6 ]
${tz} *${prefix}ytmp4* <link>
${tz} *${prefix}ytmp3* <link>
${tz} *${prefix}tiktokmp4* <link>
${tz} *${prefix}playmp3* <link>
${tz} *${prefix}playmp4* <link>
${tz} *${prefix}tiktokmp3* <link>
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *RANDOM* [ 22 ]
${tz} *${prefix}artinama* <text>
${tz} *${prefix}artimimpi* <text>
${tz} *${prefix}resepmasakan* <text>
${tz} *${prefix}katajago* <text>
${tz} *${prefix}besarkecil* <text>
${tz} *${prefix}jumlahhuruf* <text>
${tz} *${prefix}jumlahangka* <text>
${tz} *${prefix}infogempa* 
${tz} *${prefix}balikangka* <text>
${tz} *${prefix}wikipedia* <text>
${tz} *${prefix}balikhuruf* <text>
${tz} *${prefix}bilangangka* <text>
${tz} *${prefix}holoh* <text>
${tz} *${prefix}heleh* <text>
${tz} *${prefix}huluh* <text>
${tz} *${prefix}hilih* <text>
${tz} *${prefix}halah* <text>
${tz} *${prefix}kapital* <text>
${tz} *${prefix}cecan* 
${tz} *${prefix}cogan* 
${tz} *${prefix}meme* 
${tz} *${prefix}attp* <text>
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *STICKNEWS* [ 12 ]
${tz} *${prefix}sedih* <@tag>
${tz} *${prefix}takut* <@tag>
${tz} *${prefix}marah* <@tag>
${tz} *${prefix}pukul* <@tag>
${tz} *${prefix}peluk* <@tag>
${tz} *${prefix}tampar* <@tag>
${tz} *${prefix}nangis* <@tag>
${tz} *${prefix}kaget* <@tag>
${tz} *${prefix}diam* <@tag>
${tz} *${prefix}ketawa* <@tag>
${tz} *${prefix}jijik* <@tag>
${tz} *${prefix}tendang* <@tag>
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *ANIME* [ 24 ]
${tz} *${prefix}gon*
${tz} *${prefix}killua*
${tz} *${prefix}kakashi*
${tz} *${prefix}tsunade*
${tz} *${prefix}orochimaru*
${tz} *${prefix}mitsuki*
${tz} *${prefix}sarada*
${tz} *${prefix}boruto*
${tz} *${prefix}sakura*
${tz} *${prefix}sasuke*
${tz} *${prefix}minato*
${tz} *${prefix}naruto*
${tz} *${prefix}copper*
${tz} *${prefix}nami*
${tz} *${prefix}ussop*
${tz} *${prefix}sanji*
${tz} *${prefix}luffy*
${tz} *${prefix}zoro*
${tz} *${prefix}senku*
${tz} *${prefix}nezuko*
${tz} *${prefix}tanjirou*
${tz} *${prefix}natsu*
${tz} *${prefix}sagiri*
${tz} *${prefix}rimuru*
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *SEARCH* [ 10 ]
${tz} *${prefix}grubwa* <text>
${tz} *${prefix}arena* <text>
${tz} *${prefix}amazon* <text>
${tz} *${prefix}shopee* <text>
${tz} *${prefix}thelazy* <text>
${tz} *${prefix}cersex* <text>
${tz} *${prefix}ytsearch* <text>
${tz} *${prefix}rexdl* <text>
${tz} *${prefix}mod* <text>
${tz} *${prefix}sfile* <text>
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *NEWS* [ 4 ]
${tz} *${prefix}berita*
${tz} *${prefix}kompas*
${tz} *${prefix}okezone*
${tz} *${prefix}antara*
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *INFORMATION* [ 5 ]
${tz} *${prefix}jam*
${tz} *${prefix}jamdunia*
${tz} *${prefix}jadwalbola*
${tz} *${prefix}infohoax*
${tz} *${prefix}coronameninggal*
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *ISLAMIC* [ 4 ]
${tz} *${prefix}hadist*
${tz} *${prefix}quran*
${tz} *${prefix}asmaulhusna*
${tz} *${prefix}kisahnabi*
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *GAME* [ 6 ]
${tz} *${prefix}tebakgambar*
${tz} *${prefix}tebaklirik*
${tz} *${prefix}tebakkimia*
${tz} *${prefix}tebakjenaka*
${tz} *${prefix}tebakbendera*
${tz} *${prefix}caklontong*
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *NSFW* [ 19 ]
${tz} *${prefix}yuri*
${tz} *${prefix}thighs*
${tz} *${prefix}pussy*
${tz} *${prefix}panties*
${tz} *${prefix}orgy*
${tz} *${prefix}ass*
${tz} *${prefix}ahegao*
${tz} *${prefix}bdsm*
${tz} *${prefix}blowjob*
${tz} *${prefix}cuckold*
${tz} *${prefix}ero*
${tz} *${prefix}cum*
${tz} *${prefix}femdom*
${tz} *${prefix}foot*
${tz} *${prefix}gangbang*
${tz} *${prefix}glasses*
${tz} *${prefix}jahy*
${tz} *${prefix}masturbation*
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *STORAGE* [ 12 ]
${tz} *${prefix}addvn*
${tz} *${prefix}listvn*
${tz} *${prefix}getvn*
${tz} *${prefix}addimage*
${tz} *${prefix}listimage*
${tz} *${prefix}getimage*
${tz} *${prefix}addvideo*
${tz} *${prefix}listvideo*
${tz} *${prefix}getvideo*
${tz} *${prefix}addsticer*
${tz} *${prefix}liststicker*
${tz} *${prefix}getsticker*
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *CHATRANDOM* [ 2 ]
${tz} *${prefix}addchat*
${tz} *${prefix}getchat*
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *HACKERZZ!!!!* [ 5 ]
${tz} *${prefix}hackmatahari*
${tz} *${prefix}hacknegara*
${tz} *${prefix}hackbapak*
${tz} *${prefix}hacksatelit*
${tz} *${prefix}hackbulan*
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *SETGRUB* [ 8 ]
${tz} *${prefix}hellokitty*
${tz} *${prefix}horror*
${tz} *${prefix}indonesia*
${tz} *${prefix}anime*
${tz} *${prefix}bts*
${tz} *${prefix}smile*
${tz} *${prefix}halal*
${tz} *${prefix}bantengmerah*
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *AUDIO* [ 20 ]
${tz} Please select audio 1-20
${tz} For example *${prefix}audio8*
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *APPLY* [ 05 ]
${tz} Wearing a mask
${tz} Hand wash
${tz} Keep your distance
${tz} Stay away from the crowd
${tz} Restrict mobility
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *RULES* [ 5 ]
${tz} This bot does not save media/photos you send
${tz} Make the most of this bot
${tz} Don,t spam features/command bots
${tz} This bot is for entertainment purposes only, and *not to be eaten*
${tz} This bot is just a bot, can,t talk/do excessive hall like a human
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *HUKUMAN* [ 2 ]
${tz} Owner berhak memberikan teguran hingga sanksi terhadap user yang melanggar peraturan di atas
${tz} Melanggar peraturan di atas dapat mendapatkan sanksi seperti banned/block user
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *PUNISHMENT* [ 2 ]
${tz} Owner has the right to give warnings to sanctions against users who violate the rules above
${tz} Violating the rules above can get sanctions such as banned/block user
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *THX•TO* [ 6 ]
${tz} *${ownername}*
${tz} *NAYLA [ OTHER ]*
${tz} *LORD RIYAN*
${tz} *LOLKILLERS*
${tz} *ADIWAJSHING*
${tz} *WHATSAPP*
▬▭▬▭▬▭▬▭▬▭▬▭`
}

exports.helpen = helpen
// NOTE THX TO JGN DI HAPUS YAA BANH, HARGAI SAYA(RIMURUBOTZ)
