const menuen = (prefix, botname, ownername, codename, arts, tz) => {
	return `☞ MENU ${botname} ☜
▬▭▬▭▬▭▬▭▬▭▬▭
Hello brother ${codename}.👋
here is the menu *${botname}*
▬▭▬▭▬▭▬▭▬▭▬▭
${arts}
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *LIST-MENU* [ 20 ]
${tz} *${prefix}allmenu* 
${tz} *${prefix}animemenu* 
${tz} *${prefix}audiomenu* 
${tz} *${prefix}bahasamenu* 
${tz} *${prefix}cekmenu* 
${tz} *${prefix}downloadmenu* 
${tz} *${prefix}gamemenu* 
${tz} *${prefix}groupmenu* 
${tz} *${prefix}infomenu* 
${tz} *${prefix}islamimenu* 
${tz} *${prefix}newsmenu* 
${tz} *${prefix}nsfwmenu* 
${tz} *${prefix}ownermenu* 
${tz} *${prefix}randommenu* 
${tz} *${prefix}ratemenu* 
${tz} *${prefix}searchmenu* 
${tz} *${prefix}stickmenu* 
${tz} *${prefix}storagemenu* 
${tz} *${prefix}tagmenu* 
${tz} *${prefix}wallpapermenu* 
${tz} *${prefix}hackmenu*
${tz} *${prefix}setgrub*  
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *APPLY* [ 05 ]
${tz} Wearing a mask
${tz} Hand wash
${tz} Keep your distance
${tz} Stay away from the crowd
${tz} Restrict mobility
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *RULES* [ 5 ]
${tz} This bot does not save media/photos you send
${tz} Make the most of this bot
${tz} Don,t spam features/command bots
${tz} This bot is for entertainment purposes only, and *not to be eaten*
${tz} This bot is just a bot, can,t talk/do excessive hall like a human
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *HUKUMAN* [ 2 ]
${tz} Owner berhak memberikan teguran hingga sanksi terhadap user yang melanggar peraturan di atas
${tz} Melanggar peraturan di atas dapat mendapatkan sanksi seperti banned/block user
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *PUNISHMENT* [ 2 ]
${tz} Owner has the right to give warnings to sanctions against users who violate the rules above
${tz} Violating the rules above can get sanctions such as banned/block user
▬▭▬▭▬▭▬▭▬▭▬▭
☞ *THX•TO* [ 6 ]
${tz} *${ownername}*
${tz} *NAYLA [ OTHER ]*
${tz} *LORD RIYAN*
${tz} *LOLKILLERS*
${tz} *ADIWAJSHING*
${tz} *WHATSAPP*
▬▭▬▭▬▭▬▭▬▭▬▭`
}

exports.menuen = menuen
// NOTE THX TO JGN DI HAPUS YAA BANH, HARGAI SAYA(RIMURUBOTZ)
