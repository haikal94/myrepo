const audiomenu = (prefix, tz) => {
	return `☞ *AUDIO* [ 20 ]
Silahkan pilih audio 1-20
Contohnya *${prefix}audio8*`
}

exports.audiomenu = audiomenu