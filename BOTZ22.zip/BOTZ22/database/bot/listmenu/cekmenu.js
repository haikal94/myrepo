const cekmenu = (prefix, tz) => {
	return `☞ *RANDOMCEK* [ 22 ]
${tz} *${prefix}bapercek*
${tz} *${prefix}sangecek*
${tz} *${prefix}pakgirlcek*
${tz} *${prefix}pakboycek*
${tz} *${prefix}kontolcek*
${tz} *${prefix}haramcek*
${tz} *${prefix}anjingcek*
${tz} *${prefix}jahatcek*
${tz} *${prefix}baikcek*
${tz} *${prefix}bebancek*
${tz} *${prefix}babicek*
${tz} *${prefix}nolepcek*
${tz} *${prefix}jagocek*
${tz} *${prefix}pintarcek*
${tz} *${prefix}begocek*
${tz} *${prefix}goblokcek*
${tz} *${prefix}jelekcek*
${tz} *${prefix}cantikcek*
${tz} *${prefix}gantengcek*`
}

exports.cekmenu = cekmenu