const setgrub = (prefix, tz) => {
	return `☞ *SETGRUB* [ 8 ]
${tz} *${prefix}hellokitty*
${tz} *${prefix}horror*
${tz} *${prefix}indonesia*
${tz} *${prefix}anime*
${tz} *${prefix}bts*
${tz} *${prefix}smile*
${tz} *${prefix}halal*
${tz} *${prefix}bantengmerah*`
}

exports.setgrub = setgrub