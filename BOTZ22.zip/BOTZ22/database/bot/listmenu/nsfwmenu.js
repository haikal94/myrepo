const nsfwmenu = (prefix, tz) => {
	return `☞ *NSFW* [ 19 ]
${tz} *${prefix}yuri*
${tz} *${prefix}thighs*
${tz} *${prefix}pussy*
${tz} *${prefix}panties*
${tz} *${prefix}orgy*
${tz} *${prefix}ass*
${tz} *${prefix}ahegao*
${tz} *${prefix}bdsm*
${tz} *${prefix}blowjob*
${tz} *${prefix}cuckold*
${tz} *${prefix}ero*
${tz} *${prefix}cum*
${tz} *${prefix}femdom*
${tz} *${prefix}foot*
${tz} *${prefix}gangbang*
${tz} *${prefix}glasses*
${tz} *${prefix}jahy*
${tz} *${prefix}masturbation*`
}

exports.nsfwmenu = nsfwmenu