const animemenu = (prefix, tz) => {
	return `☞ *ANIME* [ 24 ]
${tz} *${prefix}gon*
${tz} *${prefix}killua*
${tz} *${prefix}kakashi*
${tz} *${prefix}tsunade*
${tz} *${prefix}orochimaru*
${tz} *${prefix}mitsuki*
${tz} *${prefix}sarada*
${tz} *${prefix}boruto*
${tz} *${prefix}sakura*
${tz} *${prefix}sasuke*
${tz} *${prefix}minato*
${tz} *${prefix}naruto*
${tz} *${prefix}copper*
${tz} *${prefix}nami*
${tz} *${prefix}ussop*
${tz} *${prefix}sanji*
${tz} *${prefix}luffy*
${tz} *${prefix}zoro*
${tz} *${prefix}senku*
${tz} *${prefix}nezuko*
${tz} *${prefix}tanjirou*
${tz} *${prefix}natsu*
${tz} *${prefix}sagiri*
${tz} *${prefix}rimuru*`
}

exports.animemenu = animemenu