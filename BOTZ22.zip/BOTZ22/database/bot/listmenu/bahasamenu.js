const bahasamenu = (prefix, tz) => {
	return `☞ *BAHASA* [ 2 ]
${tz} *${prefix}setbahasa* id
${tz} *${prefix}setlanguage* en`
}

exports.bahasamenu = bahasamenu