const randommenu = (prefix, tz) => {
	return `☞ *RANDOM* [ 22 ]
${tz} *${prefix}artinama* <text>
${tz} *${prefix}artimimpi* <text>
${tz} *${prefix}resepmasakan* <text>
${tz} *${prefix}katajago* <text>
${tz} *${prefix}besarkecil* <text>
${tz} *${prefix}jumlahhuruf* <text>
${tz} *${prefix}jumlahangka* <text>
${tz} *${prefix}infogempa* 
${tz} *${prefix}balikangka* <text>
${tz} *${prefix}wikipedia* <text>
${tz} *${prefix}balikhuruf* <text>
${tz} *${prefix}bilangangka* <text>
${tz} *${prefix}holoh* <text>
${tz} *${prefix}heleh* <text>
${tz} *${prefix}huluh* <text>
${tz} *${prefix}hilih* <text>
${tz} *${prefix}halah* <text>
${tz} *${prefix}kapital* <text>
${tz} *${prefix}cecan* 
${tz} *${prefix}cogan* 
${tz} *${prefix}meme* 
${tz} *${prefix}attp* <text>

☞ *CHATRANDOM* [ 2 ]
${tz} *${prefix}addchat*
${tz} *${prefix}getchat*`
}

exports.randommenu = randommenu