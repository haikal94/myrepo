const tagmenu = (prefix, tz) => {
	return `☞ *TAG-RANDOM* [ 22 ]
${tz} *${prefix}sadboy* 
${tz} *${prefix}pakboy* 
${tz} *${prefix}baik* 
${tz} *${prefix}jago* 
${tz} *${prefix}jelek* 
${tz} *${prefix}cantik* 
${tz} *${prefix}pinter* 
${tz} *${prefix}beban* 
${tz} *${prefix}kontol* 
${tz} *${prefix}hebat* 
${tz} *${prefix}wibu* 
${tz} *${prefix}haram* 
${tz} *${prefix}babi* 
${tz} *${prefix}bego* 
${tz} *${prefix}ganteng* 
${tz} *${prefix}anjing* 
${tz} *${prefix}monyet* 
${tz} *${prefix}sadgirl* 
${tz} *${prefix}pakgirl* 
${tz} *${prefix}jahat* 
${tz} *${prefix}nolep* 
${tz} *${prefix}goblok* `
}

exports.tagmenu = tagmenu