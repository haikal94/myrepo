const stickmenu = (prefix, tz) => {
	return `☞ *STICKNEWS* [ 12 ]
${tz} *${prefix}sedih* <@tag>
${tz} *${prefix}takut* <@tag>
${tz} *${prefix}marah* <@tag>
${tz} *${prefix}pukul* <@tag>
${tz} *${prefix}peluk* <@tag>
${tz} *${prefix}tampar* <@tag>
${tz} *${prefix}nangis* <@tag>
${tz} *${prefix}kaget* <@tag>
${tz} *${prefix}diam* <@tag>
${tz} *${prefix}ketawa* <@tag>
${tz} *${prefix}jijik* <@tag>
${tz} *${prefix}tendang* <@tag>`
}

exports.stickmenu = stickmenu