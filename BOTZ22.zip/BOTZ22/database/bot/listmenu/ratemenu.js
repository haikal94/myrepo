const ratemenu = (prefix, tz) => {
	return `☞ *TAGRATE* [ 22 ]
${tz} *${prefix}bapertag* <@tag>
${tz} *${prefix}sangetag* <@tag>
${tz} *${prefix}pakgirltag* <@tag>
${tz} *${prefix}pakboytag* <@tag>
${tz} *${prefix}kontoltag* <@tag>
${tz} *${prefix}haramtag* <@tag>
${tz} *${prefix}anjingtag* <@tag>
${tz} *${prefix}jahattag* <@tag>
${tz} *${prefix}baiktag* <@tag>
${tz} *${prefix}bebantag* <@tag>
${tz} *${prefix}babitag* <@tag>
${tz} *${prefix}noleptag* <@tag>
${tz} *${prefix}jagotag* <@tag>
${tz} *${prefix}pintartag* <@tag>
${tz} *${prefix}begotag* <@tag>
${tz} *${prefix}gobloktag* <@tag>
${tz} *${prefix}jelektag* <@tag>
${tz} *${prefix}cantiktag* <@tag>
${tz} *${prefix}gantengtag* <@tag>`
}

exports.ratemenu = ratemenu