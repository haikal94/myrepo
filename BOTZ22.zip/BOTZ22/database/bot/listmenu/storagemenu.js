const storagemenu = (prefix, tz) => {
	return `☞ *STORAGE* [ 12 ]
${tz} *${prefix}addvn*
${tz} *${prefix}listvn*
${tz} *${prefix}getvn*
${tz} *${prefix}addimage*
${tz} *${prefix}listimage*
${tz} *${prefix}getimage*
${tz} *${prefix}addvideo*
${tz} *${prefix}listvideo*
${tz} *${prefix}getvideo*
${tz} *${prefix}addsticer*
${tz} *${prefix}liststicker*
${tz} *${prefix}getsticker*`
}

exports.storagemenu = storagemenu