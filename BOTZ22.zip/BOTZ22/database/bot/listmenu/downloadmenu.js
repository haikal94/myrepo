const downloadmenu = (prefix, tz) => {
	return `☞ *DOWNLOAD* [ 6 ]
${tz} *${prefix}ytmp4* <link>
${tz} *${prefix}ytmp3* <link>
${tz} *${prefix}tiktokmp4* <link>
${tz} *${prefix}playmp3* <link>
${tz} *${prefix}playmp4* <link>
${tz} *${prefix}tiktokmp3* <link>`
}

exports.downloadmenu = downloadmenu