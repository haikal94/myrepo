const newsmenu = (prefix, tz) => {
	return `☞ *NEWS* [ 4 ]
${tz} *${prefix}berita*
${tz} *${prefix}kompas*
${tz} *${prefix}okezone*
${tz} *${prefix}antara*

☞ *INFORMATION* [ 5 ]
${tz} *${prefix}jam*
${tz} *${prefix}jamdunia*
${tz} *${prefix}jadwalbola*
${tz} *${prefix}infohoax*
${tz} *${prefix}coronameninggal*`
}

exports.newsmenu = newsmenu