const islamimenu = (prefix, tz) => {
	return `☞ *ISLAMIC* [ 4 ]
${tz} *${prefix}hadist*
${tz} *${prefix}quran*
${tz} *${prefix}asmaulhusna*
${tz} *${prefix}kisahnabi*`
}

exports.islamimenu = islamimenu