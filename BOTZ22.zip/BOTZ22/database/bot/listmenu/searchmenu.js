const searchmenu = (prefix, tz) => {
	return `☞ *SEARCH* [ 10 ]
${tz} *${prefix}grubwa* <text>
${tz} *${prefix}arena* <text>
${tz} *${prefix}amazon* <text>
${tz} *${prefix}shopee* <text>
${tz} *${prefix}thelazy* <text>
${tz} *${prefix}cersex* <text>
${tz} *${prefix}ytsearch* <text>
${tz} *${prefix}rexdl* <text>
${tz} *${prefix}mod* <text>
${tz} *${prefix}sfile* <text>`
}

exports.searchmenu = searchmenu