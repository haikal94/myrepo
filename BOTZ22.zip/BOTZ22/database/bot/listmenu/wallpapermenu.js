const wallpapermenu = (prefix, tz) => {
	return `☞ *WALLPAPER* [ 5 ]
${tz} *${prefix}wallml*
${tz} *${prefix}wallpubg*
${tz} *${prefix}wallneon*
${tz} *${prefix}wallcode*
${tz} *${prefix}wallrandom*`
}

exports.wallpapermenu = wallpapermenu