const gamemenu = (prefix, tz) => {
	return `☞ *GAME* [ 6 ]
${tz} *${prefix}tebakgambar*
${tz} *${prefix}tebaklirik*
${tz} *${prefix}tebakkimia*
${tz} *${prefix}tebakjenaka*
${tz} *${prefix}tebakbendera*
${tz} *${prefix}caklontong*`
}

exports.gamemenu = gamemenu