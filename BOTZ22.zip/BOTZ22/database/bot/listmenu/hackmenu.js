const hackmenu = (prefix, tz) => {
	return `☞ *HACKERZZ!!!!* [ 5 ]
${tz} *${prefix}hackmatahari*
${tz} *${prefix}hacknegara*
${tz} *${prefix}hackbapak*
${tz} *${prefix}hacksatelit*
${tz} *${prefix}hackbulan*`
}

exports.hackmenu = hackmenu