const iklan1 = () => {
	return `[ YOUR IKLAN ]`
}

exports.iklan1 = iklan1